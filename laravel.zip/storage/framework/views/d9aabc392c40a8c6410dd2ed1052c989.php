<h1>Payment Cancel</h1>
<p>Your payment was Cancel. Please try again</p>
<?php /**PATH C:\BaiTap\laravel\resources\views/payment/cancel.blade.php ENDPATH**/ ?>