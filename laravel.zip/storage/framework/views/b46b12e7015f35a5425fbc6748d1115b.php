<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Seats</title>
    <link href="<?php echo e(asset('assets/images/icon.png')); ?>" rel="icon" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/list.css')); ?>">
    <style>
        .seat {
            background-color: #f8f9fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            cursor: pointer;
            width: 50px;
            height: 50px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 5px;
            transition: background-color 0.3s, color 0.3s;
        }
        .seat:hover {
            background-color: #007bff;
            color: #fff;
        }
        .seat.occupied {
            background-color: #dc3545;
            color: #fff;
            cursor: not-allowed;
        }
        .seat-row {
            display: flex;
            justify-content: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div id="page-container" class="d-flex flex-column flex-root">
        <div class="d-flex flex-row flex-column-fluid page">
            <?php echo $__env->make('fragments.sidebar', ['key' => 'room', 'subkey' => 'room_all'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="d-flex flex-column wrapper">
                <?php echo $__env->make('fragments.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content container mt-4">
                    <h1 class="title mb-4">Manage Seats for Room: <?php echo e($room->room_name); ?></h1>
                    

                    <!-- Sơ đồ ghế -->
                    <!-- Seat Layout -->
                    <div class="seat-layout mb-5">
                        <?php
                            $capacity = $room->capacity;
                            $seatsPerRow = 10;
                            $rows = ceil($capacity / $seatsPerRow);
                            $seatNumber = 1;
                            $currentRowLetter = 'A';
                        ?>

                        <?php for($i = 0; $i < $rows; $i++): ?>
                            <div class="seat-row">
                                <?php for($j = 1; $j <= $seatsPerRow; $j++): ?>
                                    <?php if($seatNumber <= $capacity): ?>
                                        <?php
                                            $seatLabel = $currentRowLetter . $j;
                                            $isOccupied = $seats->contains('seat_number', $seatLabel);
                                        ?>
                                        <div class="seat <?php echo e($isOccupied ? 'occupied' : ''); ?>" title="Seat <?php echo e($seatLabel); ?>">
                                            <?php echo e($seatLabel); ?>

                                        </div>
                                        <?php $seatNumber++; ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <?php $currentRowLetter = chr(ord($currentRowLetter) + 1); ?>
                        <?php endfor; ?>
                    </div>


                    <!-- Danh sách ghế hiện tại -->
                    <div class="table-responsive">
                        <table class="table table-borderless table-striped table-vcenter">
                            <thead>
                                <tr>
                                    <th class="text-center">Seat Number</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($seat->seat_number); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('seats.edit', $seat->id)); ?>" class="btn btn-sm btn-alt-secondary" title="Edit">
                                                <i class="fas fa-pencil-alt"></i>
                                            </a>
                                            <form action="<?php echo e(route('seats.destroy', $seat->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this seat?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-alt-danger" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2" class="text-center">No seats found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Laravel Pagination Links (Nếu cần) -->
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($seats->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/index.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.4/dist/sweetalert2.all.min.js"></script>
    
    <script>
        $(document).ready(function() {
            let messageError = "<?php echo e(session('messageError')); ?>";
            let messageSuccess = "<?php echo e(session('messageSuccess')); ?>";

            if (messageSuccess) {
                Swal.fire({
                    title: '',
                    text: messageSuccess,
                    icon: 'success',
                    confirmButtonColor: '#3085d6'
                });
            }

            if (messageError) {
                Swal.fire({
                    title: '',
                    text: messageError,
                    icon: 'error'
                });
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\BaiTap\laravel\resources\views/seats/index.blade.php ENDPATH**/ ?>