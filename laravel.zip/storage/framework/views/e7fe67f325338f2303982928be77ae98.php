<!DOCTYPE html>
<html lang="en">
<header>
    <div>
        <form action="<?php echo e(route($entityName . '.index')); ?>" method="GET" class="form-inline m-3">
            <div class="input-group search-group">
                <input type="text" class="form-control search-group-input" placeholder="Search <?php echo e(ucfirst($entityName)); ?>..." value="<?php echo e(request()->get('keyword')); ?>" name="keyword">
                <div class="input-group-append search-group-append d-flex justify-content-center align-items-center">
                    <i class="fas fa-search"></i>
                </div>
                &nbsp;&nbsp;
                <?php if(request()->has('keyword') && request()->get('keyword') != ''): ?>
                    <a href="<?php echo e(route($entityName . '.index')); ?>">
                        <button type="button" class="btn" style="background-color: transparent; border: 0; box-shadow: none !important;">
                            <i class="fas fa-eraser" style="color: black"></i>
                        </button>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</header>
</html>
<?php /**PATH C:\BaiTap\laravel\resources\views/fragments/search.blade.php ENDPATH**/ ?>